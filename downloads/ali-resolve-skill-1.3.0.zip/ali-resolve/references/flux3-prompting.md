# FLUX 3 Prompt Assist

Use [BFL's current FLUX 3 Image guide](https://docs.bfl.ai/guides/prompting_summary),
[editing guide](https://docs.bfl.ai/guides/prompting_editing_multi_reference) and
[layout guide](https://docs.bfl.ai/guides/prompting_layout).

Write the finished frame: medium, subject and relationships, setting, lighting,
framing and concrete visible detail. Preserve the user's style and priorities.
Quote exact text. For edits, name the target, change and keep constraints.
Keep reference order and explicit roles; image 1 is ref_image_0. Preserve existing
layout IDs, coordinates and user-provided JSON. Never invent extra references,
identity details or box rows. Review results before applying or generating.

The hosted API has different fields from ALi's native Klein integration. Do not
remove local seeds or substitute hosted resolution/sampling settings. Distilled
uses 16 steps without CFG; Base uses 50 steps with CFG 3.5. These settings belong
in the request, not the caption. Native edits/upscales do not guarantee exact
pixel restoration. ALi's selected local Qwen/ChatGPT Prompt Assist is separate
from BFL's optional prompt upsampler.

Explore 360 Scene supports source-aware Draft/Refine for its scene description,
with a review step and protection for text/source changes during refinement.
